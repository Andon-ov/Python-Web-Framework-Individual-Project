create view pg_stat_activity
            (datid, datname, pid, leader_pid, usesysid, usename, application_name, client_addr, client_hostname,
             client_port, backend_start, xact_start, query_start, state_change, wait_event_type, wait_event, state,
             backend_xid, backend_xmin, query_id, query, backend_type)
as
SELECT s.datid,
       d.datname,
       s.pid,
       s.leader_pid,
       s.usesysid,
       u.rolname AS usename,
       s.application_name,
       s.client_addr,
       s.client_hostname,
       s.client_port,
       s.backend_start,
       s.xact_start,
       s.query_start,
       s.state_change,
       s.wait_event_type,
       s.wait_event,
       s.state,
       s.backend_xid,
       s.backend_xmin,
       s.query_id,
       s.query,
       s.backend_type
FROM pg_stat_get_activity(NULL::integer) s(datid, pid, usesysid, application_name, state, query, wait_event_type,
                                           wait_event, xact_start, query_start, backend_start, state_change,
                                           client_addr, client_hostname, client_port, backend_xid, backend_xmin,
                                           backend_type, ssl, sslversion, sslcipher, sslbits, ssl_client_dn,
                                           ssl_client_serial, ssl_issuer_dn, gss_auth, gss_princ, gss_enc, leader_pid,
                                           query_id)
         LEFT JOIN pg_database d ON s.datid = d.oid
         LEFT JOIN pg_authid u ON s.usesysid = u.oid;

alter table pg_stat_activity
    owner to postgres;

grant select on pg_stat_activity to public;

